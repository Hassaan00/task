import React from "react";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { ArrowUpward, ArrowDownward, MoreHoriz } from "@material-ui/icons";
import Timer from "@material-ui/icons/Alarm";
import AddIcon from "@material-ui/icons/Add";
import StepConnector from "@material-ui/core/StepConnector";
import { Row, Col, Container } from "react-bootstrap";
import Box from "@material-ui/core/Box";
import TextField from "@material-ui/core/TextField";
import Switch from "@material-ui/core/Switch";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { green } from "@material-ui/core/colors";
import Checkbox from "@material-ui/core/Checkbox";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  button: {
    marginRight: theme.spacing(1),
  },
  instructions: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
}));

function getSteps() {
  return [
    "Grant call setup",
    "Preview",
    "Application form setup ",
    "Preview",
    "Publish",
  ];
}
const GreenCheckbox = withStyles({
  root: {
   
    "&$checked": {
      color: green[600],
    },
  },
  checked: {},
})((props) => <Checkbox color="default" {...props} />);
function GetStepContent(step) {
  const [state, setState] = React.useState({
    checkedA: true,
    checkedB: true,
    checkedF: true,
    checkedG: true,
  });
  const handleChange = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };
  switch (step) {
    case 0:
      return (
        <Container>
          <Row>
            <Col md={8}>
              <LongTextField></LongTextField>
              <AddButton></AddButton>
              <LongTextField></LongTextField>
              <AddButton></AddButton>

              <Container>
                <Row>
                  <Col className="pl-4 pr-4">
                    <hr />
                    <h4>Documentation</h4>
                    <p>
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum is simply dummy text of
                      the printing and typesetting industry.{" "}
                    </p>
                  </Col>
                </Row>
              </Container>
            </Col>
            <Col
              md={4}
              id="aside"
              className="p-3 justify-content-center text-center"
            >
              <Box borderRadius="50%">
                <Button
                  variant="contained"
                  className="btn-round"
                  startIcon={<Timer />}
                >
                  Upload photo
                </Button>
              </Box>
              <Box className="text-left aside-con">
                <h4 className="mt-3">Funding details</h4>
                <TextField
                  id="outlined-basic"
                  label="Total grantfund sum"
                  variant="outlined"
                  className="w-100"
                />

                <TextField
                  id="outlined-basic"
                  label="Maximum grantfund sum"
                  variant="outlined"
                  className="mt-4 w-100"
                />
              </Box>

              <Box className="text-left aside-con">
                <h4 className="mt-3">Evaluation details</h4>
                <FormControlLabel
                        control={<GreenCheckbox  onChange={handleChange} name="checkedG" />}
                        label="Peer evaluaiton"
                />
                 <FormControlLabel
                        control={<GreenCheckbox onChange={handleChange} name="checkedG" />}
                        label="Committee evaluaiton"
                />

              </Box>

              <Box className="text-left aside-con">
                <h4 className="mt-3">Important details</h4>
                <TextField
                  id="date"
                  label="Call open"
                  type="date"
                  defaultValue="2017-05-24"
                  className="w-100"
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
                <TextField
                  id="date"
                  label="Call open"
                  type="date"
                  defaultValue="2017-05-24"
                  className="w-100 mt-4"
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
                <TextField
                  id="date"
                  label="Call open"
                  type="date"
                  defaultValue="2017-05-24"
                  className="w-100 mt-4"
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </Box>
            </Col>
          </Row>
        </Container>
      );
    case 1:
      return "What is an ad group anyways?";
    case 2:
      return "This is the bit I really care about!";
    default:
      return "Unknown step";
  }
}

export default function HorizontalLinearStepper() {
  const classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(0);
  const [skipped, setSkipped] = React.useState(new Set());
  const steps = getSteps();

  const isStepOptional = (step) => {
    return step === 1;
  };

  const isStepSkipped = (step) => {
    return skipped.has(step);
  };

  const handleNext = () => {
    let newSkipped = skipped;
    if (isStepSkipped(activeStep)) {
      newSkipped = new Set(newSkipped.values());
      newSkipped.delete(activeStep);
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped(newSkipped);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleSkip = () => {
    if (!isStepOptional(activeStep)) {
      // You probably want to guard against something like this,
      // it should never occur unless someone's actively trying to break something.
      throw new Error("You can't skip a step that isn't optional.");
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped((prevSkipped) => {
      const newSkipped = new Set(prevSkipped.values());
      newSkipped.add(activeStep);
      return newSkipped;
    });
  };

  const handleReset = () => {
    setActiveStep(0);
  };
  const QontoConnector = withStyles({})(StepConnector);
  return (
    <section className="bg-grey">
      <Container id="StepperForm">
        <Row>
          <div className={(classes.root, "Stepper w-100")}>
            <Stepper
              activeStep={activeStep}
              connector={<QontoConnector />}
              className="w-100"
            >
              {steps.map((label, index) => {
                const stepProps = {};
                const labelProps = {};
                if (isStepSkipped(index)) {
                  stepProps.completed = false;
                }
                return (
                  <Step key={label} {...stepProps}>
                    <StepLabel {...labelProps}>{label} </StepLabel>
                  </Step>
                );
              })}
            </Stepper>

            <div>
              <hr></hr>
              {activeStep === steps.length ? (
                <div>
                  <Typography className={classes.instructions}>
                    All steps completed - you&apos;re finished
                  </Typography>
                  <Button onClick={handleReset} className={classes.button}>
                    Reset
                  </Button>
                </div>
              ) : (
                <div>
                  <Typography className={classes.instructions}>
                    {GetStepContent(activeStep)}
                  </Typography>
                  <div>
                    <Button
                      disabled={activeStep === 0}
                      onClick={handleBack}
                      className={classes.button}
                    >
                      Back
                    </Button>
                    {isStepOptional(activeStep) && (
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={handleSkip}
                        className={classes.button}
                      >
                        Skip
                      </Button>
                    )}

                    <Button
                      variant="contained"
                      color="primary"
                      onClick={handleNext}
                      className={classes.button}
                    >
                      {activeStep === steps.length - 1 ? "Finish" : "Next"}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </Row>
      </Container>
    </section>
  );
}

function LongTextField() {
  return (
    <div className="dotted-card">
      <div className="headerCard">
        <Row className="justify-content-space-between align-items-center">
          <Col xs={9}>
            <h4>Long text field</h4>
          </Col>
          <Col xs={3} className="text-right">
            <ArrowUpward></ArrowUpward>
            <ArrowDownward className="ml-2 mr-2"></ArrowDownward>
            <MoreHoriz></MoreHoriz>
          </Col>
        </Row>
      </div>
      <TextField
        id="outlined-basic"
        label="Title"
        variant="outlined"
        className="mt-4 w-100"
      />
      <textarea
        rows={5}
        cols={5}
        placeholder="Now write something brilliant"
        className="w-100 mt-3 p-2"
      />
      <FormControlLabel
        control={
          <Switch
            // checked={state.checkedB}
            // onChange={handleChange}
            name="checkedB"
            color="primary"
          />
        }
        label="Add document to block"
      />
    </div>
  );
}

function AddButton() {
  return (
    <div
      className="d-flex p-3 text-center justify-content-center"
      id="bottonContainer"
    >
      <Button variant="contained" color="default" className="round-btn">
        <AddIcon />
      </Button>
    </div>
  );
}

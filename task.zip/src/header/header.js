import { Row, Col, Container } from "react-bootstrap";
import { makeStyles } from "@material-ui/core/styles";
import Input from "@material-ui/core/Input";
import Avatar from "@material-ui/core/Avatar";
import InputLabel from "@material-ui/core/InputLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
import FormControl from "@material-ui/core/FormControl";
import TextField from "@material-ui/core/TextField";
import Grid from "@material-ui/core/Grid";
import Search from '@material-ui/icons/SearchRounded';
import Logo from '../../src/img/logo.png';
import Messenger from '../../src/img/messenger.png';
import Notification from '../../src/img/notification.png';
import Profile from '../../src/img/profile.png';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faCoffee} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
  },
}));
function Header() {
  return (
    <div className="topBar">
      <header className="border-bottom">
        <Container fluid>
          <Row>
            <Col md={3} className="d-flex justify-content-space-between align-items-center">
             <img srcSet={Logo}/>
              <FormControl className="full-width ml-2">
                <Input
                  id="input-with-icon-adornment"
                  startAdornment={
                    <InputAdornment position="start" >
                      <Search/>
                    </InputAdornment>
                  }
                  placeholder="Search for People, Calls, and Projects"
                />
              </FormControl>
            </Col>
            <Col md={9} className="text-right meun">
              <Menu></Menu>
            </Col>
          </Row>
        </Container>
      </header>
    </div>
  );
}

function Menu(){
    return(
        <div className="inner-container">
            <a href="">Home</a>
            <a href="">Grant</a>
            <a href="">Projects</a>
            <a href=""><img srcSet={Messenger}/></a>
            <a href=""> <span className="notification_circle"></span><img srcSet={Notification}/></a>
            <a href="">
                <div className="d-flex align-items-center">
                    <Avatar/>
                    <span className="pl-2"> Jone</span>
                </div>
            </a>
        </div>
    );
}

export default Header;

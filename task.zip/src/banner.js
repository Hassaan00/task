import React from "react";
import Input from "@material-ui/core/Input";
import InputLabel from "@material-ui/core/InputLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Timer from "@material-ui/icons/Alarm";
// import DownArrow from "@material-ui/icons/ArrowDownward";
// import TextField from "@material-ui/core/TextField";
// import { borders } from "@material-ui/system";
import Box from "@material-ui/core/Box";
import Select from "@material-ui/core/Select";
import FormHelperText from "@material-ui/core/FormHelperText";
import MenuItem from "@material-ui/core/MenuItem";
import { makeStyles } from "@material-ui/core/styles";

import Grid from "@material-ui/core/Grid";
import Edit from "@material-ui/icons/Edit";
import { Row, Col, Container } from "react-bootstrap";
const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));
function CoverBanner() {
  const classes = useStyles();
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  return (
    <div className="banner">
      <Container>
        <Row className="align-items-center pl-3 pr-3">
          <Col id="Cover" md={5}>
            <FormControl className="full-width">
              <InputLabel htmlFor="input-with-icon-adornment">
                Give me a name
              </InputLabel>
              <Input
                id="input-with-icon-adornment"
                endAdornment={
                  <InputAdornment position="end">
                    <Edit />
                  </InputAdornment>
                }
              />
            </FormControl>
            <Row className="pt-3">
              <Col className="d-flex align-items-center p-0">
              <span className="ml-4 mr-2 color-white">by</span>
                <FormControl className={(classes.formControl, "select")}>
                  <InputLabel
                    shrink
                    id="demo-simple-select-placeholder-label-label"
                  ></InputLabel>
                  <Select
                    labelId="demo-simple-select-placeholder-label-label"
                    id="demo-simple-select-placeholder-label"
                    value={age}
                    onChange={handleChange}
                    displayEmpty
                    className={classes.selectEmpty}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>Ten</MenuItem>
                    <MenuItem value={20}>Twenty</MenuItem>
                    <MenuItem value={30}>Thirty</MenuItem>
                  </Select>
                </FormControl>
              </Col>
              <Col className="d-flex align-items-center p-0">
                <span className="ml-2 mr-2 color-white">from</span>
                <FormControl className={(classes.formControl, "select")}>
                  <InputLabel
                    shrink
                    id="demo-simple-select-placeholder-label-label"
                  ></InputLabel>
                  <Select
                    labelId="demo-simple-select-placeholder-label-label"
                    id="demo-simple-select-placeholder-label"
                    value={age}
                    onChange={handleChange}
                    displayEmpty
                    className={classes.selectEmpty}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value={10}>Ten</MenuItem>
                    <MenuItem value={20}>Twenty</MenuItem>
                    <MenuItem value={30}>Thirty</MenuItem>
                  </Select>
                </FormControl>
              </Col>
            </Row>
          </Col>
          <Col
            id="Cover"
            md={7}
            className="d-flex align-item-center justify-content-end"
          >
            <Box borderRadius="50%">
              <Button
                variant="contained"
                className="btn-round"
                startIcon={<Timer />}
              >
                Add cover photo
              </Button>
            </Box>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default CoverBanner;

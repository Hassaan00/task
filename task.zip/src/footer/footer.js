import { Container,Row ,Col} from 'react-bootstrap';


function Footer(){
    return(
        <Row>
            <Container>
                <Col>ffff</Col>
            </Container>
        </Row>
    );
}

export default Footer;
 
import './App.scss';
import Header from '../src/header/header';
import Footer from '../src/footer/footer';
import CoverBanner from '../src/banner.js';
import From from '../src/form.js';
function App() {
  return (
    <div className="App">
      <Header></Header>
      <CoverBanner></CoverBanner>
      <From></From>
      <Footer></Footer>
    </div>
  );
}

export default App;
